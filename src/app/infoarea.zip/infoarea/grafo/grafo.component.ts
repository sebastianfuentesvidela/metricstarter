//     import { Component } from '@angular/core';
//     import { environment as env } from '@env/environment';
//     import { ROUTE_ANIMATIONS_ELEMENTS } from '@app/core';
//     import { SimpleTimer } from 'ng2-simple-timer';

//     import { UserService } from '../../services/user.service';
//     import { MetricService } from '../../services/metric.service';
//     import { GLOBAL } from '../../services/global';


//     @Component({
//       selector: 'line-chart-demo',
//       templateUrl: './grafo.component.html'
//     })
//     export class GrafoComponent {
//       public routeAnimationsElements = ROUTE_ANIMATIONS_ELEMENTS;
//       public titulo = 'Curvas';
//       public identity;
//       public token;
//       public url;
//       public metrics: any[];
//       public phpurl;
//       public counter1 = 0;
//       public timer1Id: string;
//       public timer1button = 'time';

//       public counter2 = 0;
//       public timer2Id: string;
//       public timer2button = 'time';

//       constructor(
//         //  private _chartsService: ChartsService,
//           private _userService: UserService,
//           private _metricService: MetricService,
//           private st: SimpleTimer
//         ) {
//               this.titulo = 'Diario Metricas';
//               this.titulo = 'Metricas';
//               this.identity = this._userService.getIdentity();
//               this.token = this._userService.getToken();
//               this.url = GLOBAL.url;
//               this.phpurl = GLOBAL.phpurl;

//              // this.prendemetric();
//              // this.randomize();
//               // for (let i = 0; i < 100; i++) {
//               //   this.xAxisData.push('Type ' + i);
//               //   this.data1.push((Math.sin(i / 5) * (i / 5 - 10) + i / 6) * 5);
//               //   this.data2.push((Math.cos(i / 5) * (i / 5 - 10) + i / 6) * 5);
//               // }

//         }

//             // lineChart
//       public lineChartData: Array<any> = [
//         {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
//         {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
//         {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C'}
//       ];
//       public lineChartLabels:Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
//       public lineChartOptions:any = {
//         responsive: true
//       };
//       public lineChartColors:Array<any> = [
//         { // grey
//           backgroundColor: 'rgba(148,159,177,0.2)',
//           borderColor: 'rgba(148,159,177,1)',
//           pointBackgroundColor: 'rgba(148,159,177,1)',
//           pointBorderColor: '#fff',
//           pointHoverBackgroundColor: '#fff',
//           pointHoverBorderColor: 'rgba(148,159,177,0.8)'
//         },
//         { // dark grey
//           backgroundColor: 'rgba(77,83,96,0.2)',
//           borderColor: 'rgba(77,83,96,1)',
//           pointBackgroundColor: 'rgba(77,83,96,1)',
//           pointBorderColor: '#fff',
//           pointHoverBackgroundColor: '#fff',
//           pointHoverBorderColor: 'rgba(77,83,96,1)'
//         },
//         { // grey
//           backgroundColor: 'rgba(148,159,177,0.2)',
//           borderColor: 'rgba(148,159,177,1)',
//           pointBackgroundColor: 'rgba(148,159,177,1)',
//           pointBorderColor: '#fff',
//           pointHoverBackgroundColor: '#fff',
//           pointHoverBorderColor: 'rgba(148,159,177,0.8)'
//         }
//       ];
//       public lineChartLegend: true;
//       public lineChartType: 'line';

//       public randomize(): void {
//         let _lineChartData: Array<any> = new Array(this.lineChartData.length);
//         for (let i = 0; i < this.lineChartData.length; i++) {
//           _lineChartData[i] = {data: new Array(this.lineChartData[i].data.length), label: this.lineChartData[i].label};
//           for (let j = 0; j < this.lineChartData[i].data.length; j++) {
//             _lineChartData[i].data[j] = Math.floor((Math.random() * 100) + 1);
//           }
//         }
//         this.lineChartData = _lineChartData;
//       }
//   public prendemetric() {
//     this._metricService.metricadiaria('dia', [1, 9, 3]).subscribe(
//       // tslint:disable-next-line:no-shadowed-variable
//       response => {
//         console.log(' JSONNNN: ' + JSON.stringify(response));
//         //   this.metrics = response.result;
//         //   this.xAxisData = [];
//         //   this.data1 = [];
//         //   this.data2 = [];
//         const _arr1: Array<any> = [];
//         const _arr2: Array<any> = [];
//         const _arr3: Array<any> = [];
//    //     this.lineChartLabels = [];

//         for (let i = 0; i < response.result.length; i++) {
//           _arr1.push(Number(response.result[i].MAXT0));
//           _arr2.push(Number(response.result[i].MINT0));
//           _arr3.push(Number(response.result[i].AVGT0));
//      //     this.lineChartLabels.push(response.result[i].HORA);

//           }
//           // tslint:disable-next-line:no-unused-expression
//           const _lineChartData = [
//             {data: _arr1, label: 'Series A'},
//             {data: _arr2, label: 'Series B'},
//             {data: _arr3, label: 'Series C'}
//           ];
//           console.log(_lineChartData);
//        //   this.lineChartData = _lineChartData;
//         // //   this.lineChartData = _lineChartData;
//         //   for (let i = 0; i < this.lineChartData.length; i++) {
//         //     _lineChartData[i] = {data: new Array(this.lineChartData[i].data.length), label: this.lineChartData[i].label};
//         //     for (let j = 0; j < this.lineChartData[i].data.length; j++) {
//         //       _lineChartData[i].data[j] = Math.floor((Math.random() * 100) + 1);
//         //     }
//         //   }
//         //   this.lineChartData = _lineChartData;
//         },
//       error => {
//           const errorMessage = <any>error;
//           if (errorMessage != null) {
//               console.log(error);
//           }
//     });
//   }
//       // events
//       public chartClicked(e:any):void {
//         console.log(e);
//       }

//       public chartHovered(e:any):void {
//         console.log(e);
//       }
// }



    import { Component } from '@angular/core';
    import { environment as env } from '@env/environment';
    import { ROUTE_ANIMATIONS_ELEMENTS } from '@app/core';
    import { SimpleTimer } from 'ng2-simple-timer';

    import { UserService } from '../../services/user.service';
    import { MetricService } from '../../services/metric.service';
    import { GLOBAL } from '../../services/global';


@Component({
  selector: 'line-chart-demo',
  templateUrl: './grafo.component.html'
})
export class GrafoComponent {
      public titulo = 'Curvas';
      public identity;
      public token;
      public url;
      public phpurl;
  // lineChart
  public lineChartData = [];
  // : Array<any> = [
  //   {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
  //   {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
  //   {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C'}
  // ];
  public lineChartLabels = [];
  // : Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
  public lineChartOptions: any = {
    responsive: true
  };
  public lineChartColors: Array<any> = [
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    },
    { // dark grey
      backgroundColor: 'rgba(77,83,96,0.2)',
      borderColor: 'rgba(77,83,96,1)',
      pointBackgroundColor: 'rgba(77,83,96,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(77,83,96,1)'
    },
    { // grey
      backgroundColor: 'rgba(148,159,177,0.2)',
      borderColor: 'rgba(148,159,177,1)',
      pointBackgroundColor: 'rgba(148,159,177,1)',
      pointBorderColor: '#fff',
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgba(148,159,177,0.8)'
    }
  ];
  public lineChartLegend:boolean = true;
  public lineChartType:string = 'line';

  public randomize():void {
    let _lineChartData: Array<any> = new Array(this.lineChartData.length);
    for (let i = 0; i < this.lineChartData.length; i++) {
      _lineChartData[i] = {data: new Array(this.lineChartData[i].data.length), label: this.lineChartData[i].label};
      for (let j = 0; j < this.lineChartData[i].data.length; j++) {
        _lineChartData[i].data[j] = Math.floor((Math.random() * 100) + 1);
      }
    }
    this.lineChartData = _lineChartData;
  }

  // events
  public chartClicked(e:any):void {
    console.log(e);
  }

  public chartHovered(e:any):void {
    console.log(e);
  }
  public prendemetric() {
    this._metricService.metricadiaria('dia', [1, 9, 3]).subscribe(
      // tslint:disable-next-line:no-shadowed-variable
      response => {
        console.log(' JSONNNN: ' + JSON.stringify(response));
        //   this.metrics = response.result;
        //   this.xAxisData = [];
        //   this.data1 = [];
        //   this.data2 = [];
        const _arr1: Array<any> = [];
        const _arr2: Array<any> = [];
        const _arr3: Array<any> = [];
        this.lineChartLabels = [];

        for (let i = 0; i < response.result.length; i++) {
          _arr1.push(Number(response.result[i].MAXT0));
          _arr2.push(Number(response.result[i].MINT0));
          _arr3.push(Number(response.result[i].AVGT0));
          this.lineChartLabels.push(response.result[i].HORA);

          }
          // tslint:disable-next-line:no-unused-expression
          this.lineChartData = [
            {data: _arr1, label: 'Series A'},
            {data: _arr2, label: 'Series B'},
            {data: _arr3, label: 'Series C'}
          ];
          console.log(JSON.stringify(this.lineChartLabels));
          console.log(JSON.stringify(this.lineChartData));
       //   this.lineChartData = _lineChartData;
        // //   this.lineChartData = _lineChartData;
        //   for (let i = 0; i < this.lineChartData.length; i++) {
        //     _lineChartData[i] = {data: new Array(this.lineChartData[i].data.length), label: this.lineChartData[i].label};
        //     for (let j = 0; j < this.lineChartData[i].data.length; j++) {
        //       _lineChartData[i].data[j] = Math.floor((Math.random() * 100) + 1);
        //     }
        //   }
        // this.lineChartLabels = _lineChartLabels;
        // this.lineChartData = _lineChartData;


        },
      error => {
          const errorMessage = <any>error;
          if (errorMessage != null) {
              console.log(error);
          }
    });
  }
      // events
      constructor(
        //  private _chartsService: ChartsService,
          private _userService: UserService,
          private _metricService: MetricService,
          private st: SimpleTimer
        ) {
              this.titulo = 'Diario Metricas';
              this.titulo = 'Metricas';
              this.identity = this._userService.getIdentity();
              this.token = this._userService.getToken();
              this.url = GLOBAL.url;
              this.phpurl = GLOBAL.phpurl;

              this.prendemetric();
            //  this.randomize();
              // for (let i = 0; i < 100; i++) {
              //   this.xAxisData.push('Type ' + i);
              //   this.data1.push((Math.sin(i / 5) * (i / 5 - 10) + i / 6) * 5);
              //   this.data2.push((Math.cos(i / 5) * (i / 5 - 10) + i / 6) * 5);
              // }

        }

}

